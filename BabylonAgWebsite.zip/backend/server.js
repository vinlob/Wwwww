
const express = require('express');
const nodemailer = require('nodemailer');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// Initialize express app
const app = express();
app.use(cors());

// Configure multer for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  },
});

const upload = multer({ storage });

// Configure Nodemailer transport
const transporter = nodemailer.createTransport({
  service: 'gmail',  // Use your email service here
  auth: {
    user: 'youremail@gmail.com',  // Replace with your email
    pass: 'yourpassword',         // Replace with your email password or an app-specific password
  },
});

// API endpoint to handle form submission
app.post('/api/send-email', upload.single('resume'), (req, res) => {
  const { name, email } = req.body;
  const resumePath = req.file.path;

  // Email options
  const mailOptions = {
    from: email,
    to: 'destinationemail@gmail.com', // Replace with the email where applications should be sent
    subject: 'New Job Application',
    text: `Name: ${name}
Email: ${email}`,
    attachments: [
      {
        filename: req.file.originalname,
        path: resumePath,
      },
    ],
  };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Error sending email:', error);
      return res.status(500).send('Error sending email');
    }

    // Clean up the uploaded resume file after sending the email
    fs.unlink(resumePath, (err) => {
      if (err) console.error('Error deleting file:', err);
    });

    res.send('Email sent successfully');
  });
});

// Serve the static files from the "uploads" folder if needed
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
