
import React, { useState, useContext } from 'react';
import { CartContext } from '../context/CartContext';
import './Merch.css';

const Merch = () => {
  const { addToCart } = useContext(CartContext);
  const [selectedSize, setSelectedSize] = useState('Medium');

  const handleSizeChange = (event) => {
    setSelectedSize(event.target.value);
  };

  const handleAddToCart = (product, price, size = null) => {
    const item = { product, price, size };
    addToCart(item);
  };

  return (
    <div className="merch-container">
      <h2>BabylonAG Merchandise</h2>

      <div className="product">
        <h3>BabylonAG T-Shirt</h3>
        <img src="tshirt.jpg" alt="BabylonAG T-Shirt" />
        <p>Price: $25</p>
        <label htmlFor="size">Choose a size:</label>
        <select id="size" value={selectedSize} onChange={handleSizeChange}>
          <option value="Small">Small</option>
          <option value="Medium">Medium</option>
          <option value="Large">Large</option>
          <option value="X-Large">X-Large</option>
        </select>
        <br />
        <button onClick={() => handleAddToCart('BabylonAG T-Shirt', 25, selectedSize)}>Add to Cart</button>
      </div>

      <div className="product">
        <h3>BabylonAG Hat</h3>
        <img src="hat.jpg" alt="BabylonAG Hat" />
        <p>Price: $15</p>
        <button onClick={() => handleAddToCart('BabylonAG Hat', 15)}>Add to Cart</button>
      </div>
    </div>
  );
};

export default Merch;
