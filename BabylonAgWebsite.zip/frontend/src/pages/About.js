
import React from 'react';

const About = () => {
  return (
    <div>
      <h2>About BabylonAG</h2>
      <p>BabylonAG is a community for Texas A&M students and alumni to stay connected, find unique merch, and explore employment opportunities.</p>
      <div>
        <h3>Latest Posts</h3>
        <img src="post1.jpg" alt="Post 1" />
        <img src="post2.jpg" alt="Post 2" />
      </div>
    </div>
  );
}

export default About;
