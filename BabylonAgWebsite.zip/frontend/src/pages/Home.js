
import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Welcome to BabylonAG</h2>
      <p>Your hub for Texas A&M updates, merchandise, and opportunities.</p>
    </div>
  );
}

export default Home;
