
import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

const Checkout = () => {
  const { cart } = useContext(CartContext);
  const navigate = useNavigate();

  const total = cart.reduce((acc, item) => acc + item.price, 0);

  const handleOrderSubmit = () => {
    alert('Order submitted successfully!');
    navigate('/');
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <ul>
        {cart.map((item, index) => (
          <li key={index}>
            {item.product} {item.size && `(Size: ${item.size})`} - ${item.price}
          </li>
        ))}
      </ul>
      <h3>Total: ${total}</h3>
      <button onClick={handleOrderSubmit}>Submit Order</button>
    </div>
  );
};

export default Checkout;
